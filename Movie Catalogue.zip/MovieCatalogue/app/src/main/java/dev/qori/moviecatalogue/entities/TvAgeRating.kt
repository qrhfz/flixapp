package dev.qori.moviecatalogue.entities

enum class TvAgeRating(val text: String) {
    TV_G("TV-G"),
    TV_PG("TV-PG"),
    TV_14("TV-14"),
    TV_MA("TV-MA")
}